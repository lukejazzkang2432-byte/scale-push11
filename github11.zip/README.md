# SCALE 푸시 알림 발송기

15분마다 자동으로 실행되며, 예약된 마감 알림과 아직 보내지 않은 알림을 학회원 폰으로 발송합니다.

## 설정 방법

1. 이 저장소를 만들고 파일을 올립니다.
2. Firebase 콘솔 → 프로젝트 설정 → **서비스 계정** → "새 비공개 키 생성" → JSON 다운로드
3. 이 저장소의 **Settings → Secrets and variables → Actions → New repository secret**
   - Name: `SA_KEY`
   - Secret: 다운로드한 JSON 파일 내용 **전체**를 붙여넣기
4. **Actions** 탭 → "I understand my workflows, go ahead and enable them" 클릭
5. 좌측 "SCALE 푸시 알림" → **Run workflow** 로 한 번 직접 실행해서 확인

## 주의

- `SA_KEY`는 비밀번호와 같습니다. 저장소를 **Private**으로 만드세요.
- 실행이 예약 시각보다 5~15분 늦을 수 있습니다.
- `.keepalive` 커밋은 저장소를 활성 상태로 유지해 자동 실행이 멈추지 않게 합니다.
